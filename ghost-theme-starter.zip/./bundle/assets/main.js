(function () {
	'use strict';

	console.log('Main Script');

}());
